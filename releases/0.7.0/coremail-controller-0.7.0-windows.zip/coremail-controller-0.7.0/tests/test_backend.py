from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
MCP_DIR = ROOT / "mcp"
sys.path.insert(0, str(MCP_DIR))

from coremail_backend import (  # noqa: E402
    ConfigError,
    CoremailBackend,
    CoremailError,
    Endpoint,
    PreparedMessageError,
    PreparedStore,
    Settings,
    StaleMessageError,
    build_email,
    imap_utf7_decode,
    imap_utf7_encode,
    load_settings,
    parse_message,
    prepare_message,
    select_folder,
)
from local_discovery import discover_local  # noqa: E402


def settings_for(directory: Path) -> Settings:
    return Settings(
        config_path=directory / "config.json",
        transport="imap_smtp",
        username="sender@example.com",
        credential_target="test-target",
        imap=Endpoint("imap.example.com", 993, "ssl"),
        smtp=Endpoint("smtp.example.com", 465, "ssl"),
        allowed_from=("sender@example.com",),
        drafts_folder="Drafts",
        sent_folder="Sent",
        sent_copy_mode="none",
        ca_file=None,
        attachment_roots=(directory.resolve(),),
        max_message_bytes=10 * 1024 * 1024,
        max_body_chars=50_000,
        max_attachment_bytes=25 * 1024 * 1024,
        max_recipients=100,
        timeout_seconds=20,
    )


def mapi_settings_for(directory: Path) -> Settings:
    return Settings(
        config_path=directory / "config.json",
        transport="windows_simple_mapi",
        username="sender@example.com",
        credential_target=None,
        imap=None,
        smtp=None,
        allowed_from=("sender@example.com",),
        drafts_folder=None,
        sent_folder=None,
        sent_copy_mode="none",
        ca_file=None,
        attachment_roots=(directory.resolve(),),
        max_message_bytes=10 * 1024 * 1024,
        max_body_chars=50_000,
        max_attachment_bytes=25 * 1024 * 1024,
        max_recipients=100,
        timeout_seconds=20,
    )


class SettingsTests(unittest.TestCase):
    def test_loads_non_secret_configuration(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            config = {
                "username": "sender@example.com",
                "credential_target": "ClaudeCode.Coremail:sender@example.com",
                "imap": {"host": "imap.example.com", "port": 993, "security": "ssl"},
                "smtp": {"host": "smtp.example.com", "port": 587, "security": "starttls"},
                "allowed_from": ["sender@example.com"],
                "attachment_roots": [str(directory)],
            }
            path = directory / "config.json"
            path.write_text(json.dumps(config), encoding="utf-8")
            loaded = load_settings(path, environ={"CLAUDE_PROJECT_DIR": str(directory)})
            summary = loaded.public_summary()
            self.assertEqual(loaded.smtp.security, "starttls")
            self.assertEqual(loaded.transport, "imap_smtp")
            self.assertNotIn("password", json.dumps(summary).lower())
            self.assertEqual(summary["username"], "sender@example.com")

    def test_loads_password_free_simple_mapi_configuration(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            path = directory / "config.json"
            path.write_text(
                json.dumps(
                    {
                        "transport": "windows_simple_mapi",
                        "username": "sender@example.com",
                        "allowed_from": ["sender@example.com"],
                        "sent_copy_mode": "none",
                    }
                ),
                encoding="utf-8",
            )
            loaded = load_settings(path, environ={})
            self.assertEqual(loaded.transport, "windows_simple_mapi")
            self.assertIsNone(loaded.credential_target)
            self.assertIsNone(loaded.imap)
            self.assertIsNone(loaded.smtp)
            self.assertNotIn("password", json.dumps(loaded.public_summary()).lower())

    def test_rejects_protocol_or_alias_fields_in_simple_mapi_configuration(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = {
                "transport": "windows_simple_mapi",
                "username": "sender@example.com",
                "allowed_from": ["sender@example.com"],
            }
            path = directory / "config.json"
            path.write_text(
                json.dumps({**base, "credential_target": "unexpected"}),
                encoding="utf-8",
            )
            with self.assertRaises(ConfigError):
                load_settings(path, environ={})
            path.write_text(
                json.dumps({**base, "allowed_from": ["alias@example.com"]}),
                encoding="utf-8",
            )
            with self.assertRaises(ConfigError):
                load_settings(path, environ={})

    def test_rejects_plaintext_protocol_mode(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            path = directory / "config.json"
            path.write_text(
                json.dumps(
                    {
                        "username": "sender@example.com",
                        "imap": {"host": "imap.example.com", "port": 143, "security": "plain"},
                        "smtp": {"host": "smtp.example.com", "port": 465, "security": "ssl"},
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ConfigError):
                load_settings(path, environ={})

    def test_rejects_secret_or_url_fields_in_non_secret_config(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            base = {
                "username": "sender@example.com",
                "imap": {"host": "imap.example.com", "port": 993, "security": "ssl"},
                "smtp": {"host": "smtp.example.com", "port": 465, "security": "ssl"},
            }
            path = directory / "config.json"
            path.write_text(json.dumps({**base, "password": "must-not-be-here"}), encoding="utf-8")
            with self.assertRaises(ConfigError):
                load_settings(path, environ={})

            base["imap"]["host"] = "imaps://user:secret@imap.example.com"
            path.write_text(json.dumps(base), encoding="utf-8")
            with self.assertRaises(ConfigError):
                load_settings(path, environ={})


class MailEncodingTests(unittest.TestCase):
    def test_modified_utf7_round_trip(self) -> None:
        for value in ("INBOX", "草稿箱", "项目 & 归档", "已发送/2026"):
            self.assertEqual(imap_utf7_decode(imap_utf7_encode(value)), value)

    def test_parse_html_and_attachment_without_executing_content(self) -> None:
        raw = (
            b"From: sender@example.com\r\n"
            b"To: user@example.com\r\n"
            b"Subject: Example\r\n"
            b"MIME-Version: 1.0\r\n"
            b"Content-Type: multipart/mixed; boundary=x\r\n\r\n"
            b"--x\r\nContent-Type: text/html; charset=utf-8\r\n\r\n"
            b"<p>Hello</p><script>ignore me</script><p>World</p>\r\n"
            b"--x\r\nContent-Type: application/octet-stream\r\n"
            b"Content-Disposition: attachment; filename=test.bin\r\n\r\nabc\r\n"
            b"--x--\r\n"
        )
        parsed = parse_message(raw, 1000)
        self.assertIn("Hello", parsed["body"])
        self.assertNotIn("ignore me", parsed["body"])
        self.assertEqual(parsed["attachments"][0]["filename"], "test.bin")
        self.assertTrue(parsed["content_is_untrusted"])


class PreparedMessageTests(unittest.TestCase):
    def test_attachment_outside_authorized_root_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as raw_root, tempfile.TemporaryDirectory() as raw_outside:
            root = Path(raw_root)
            outside = Path(raw_outside) / "outside.txt"
            outside.write_text("not authorized", encoding="utf-8")
            with self.assertRaisesRegex(CoremailError, "outside the authorized roots"):
                prepare_message(
                    settings_for(root),
                    {"to": ["recipient@example.com"], "attachments": [str(outside)]},
                )

    def test_preparation_and_attachment_hash_are_immutable(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            attachment = directory / "report.txt"
            attachment.write_text("approved", encoding="utf-8")
            settings = settings_for(directory)
            prepared = prepare_message(
                settings,
                {
                    "to": ["Recipient <recipient@example.com>"],
                    "bcc": ["audit@example.com"],
                    "subject": "Review",
                    "body_text": "Please review.",
                    "attachments": [str(attachment)],
                },
            )
            message = build_email(prepared)
            self.assertEqual(message["Subject"], "Review")
            self.assertIn("audit@example.com", str(message["Bcc"]))
            attachment.write_text("changed", encoding="utf-8")
            with self.assertRaises(PreparedMessageError):
                build_email(prepared)

    def test_store_expires_tokens(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            message = prepare_message(
                settings_for(Path(raw_directory)),
                {"to": ["recipient@example.com"], "subject": "x", "body_text": "y"},
            )
            store = PreparedStore(ttl_seconds=1)
            with patch("coremail_backend.time.monotonic", side_effect=[10.0, 12.0]):
                token, _ = store.put(message)
                with self.assertRaises(PreparedMessageError):
                    store.get(token)

    def test_send_requires_exact_confirmation_before_consuming_token(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            settings = settings_for(Path(raw_directory))
            message = prepare_message(
                settings,
                {"to": ["recipient@example.com"], "subject": "x", "body_text": "y"},
            )
            backend = CoremailBackend()
            token, _ = backend.store.put(message)
            with self.assertRaises(PreparedMessageError):
                backend.send_prepared({"prepared_token": token, "confirmation": "yes"})
            self.assertIs(backend.store.get(token), message)
            with patch("coremail_backend.load_settings", return_value=settings), patch(
                "coremail_backend.send_message", return_value={"smtp_submitted": True}
            ) as send:
                result = backend.send_prepared({"prepared_token": token, "confirmation": "确认发送"})
            self.assertTrue(result["smtp_submitted"])
            send.assert_called_once_with(settings, message)
            with self.assertRaises(PreparedMessageError):
                backend.store.get(token)

    def test_mapi_send_uses_verified_attachment_snapshot(self) -> None:
        class RecordingMapiClient:
            def __init__(self) -> None:
                self.values = None
                self.snapshot_content = None

            def send(self, **values):
                self.values = values
                self.snapshot_content = Path(values["attachments"][0][0]).read_text(encoding="utf-8")
                return {"mapi_submitted": True}

            def close(self):
                return None

        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            original = directory / "report.txt"
            original.write_text("approved", encoding="utf-8")
            settings = mapi_settings_for(directory)
            message = prepare_message(
                settings,
                {"to": ["recipient@example.com"], "attachments": [str(original)]},
            )
            client = RecordingMapiClient()
            backend = CoremailBackend(mapi_client=client)
            token, _ = backend.store.put(message)
            with patch("coremail_backend.load_settings", return_value=settings):
                result = backend.send_prepared(
                    {"prepared_token": token, "confirmation": "确认发送"}
                )
            self.assertTrue(result["mapi_submitted"])
            self.assertEqual(client.snapshot_content, "approved")
            self.assertNotEqual(Path(client.values["attachments"][0][0]), original)
            self.assertFalse(Path(client.values["attachments"][0][0]).exists())

    def test_mapi_unsupported_draft_or_threading_does_not_consume_token(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            settings = mapi_settings_for(directory)
            backend = CoremailBackend()
            draft = prepare_message(settings, {"to": ["recipient@example.com"]})
            draft_token, _ = backend.store.put(draft)
            with patch("coremail_backend.load_settings", return_value=settings):
                with self.assertRaisesRegex(CoremailError, "Saving drafts"):
                    backend.save_draft({"prepared_token": draft_token})
            self.assertIs(backend.store.get(draft_token), draft)

            reply = prepare_message(
                settings,
                {"to": ["recipient@example.com"], "in_reply_to": "<prior@example.com>"},
            )
            reply_token, _ = backend.store.put(reply)
            with patch("coremail_backend.load_settings", return_value=settings):
                with self.assertRaisesRegex(PreparedMessageError, "cannot preserve"):
                    backend.send_prepared(
                        {"prepared_token": reply_token, "confirmation": "确认发送"}
                    )
            self.assertIs(backend.store.get(reply_token), reply)

    def test_mapi_subject_limit_prevents_provider_truncation(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            settings = mapi_settings_for(Path(raw_directory))
            with self.assertRaisesRegex(CoremailError, "255-character"):
                prepare_message(
                    settings,
                    {"to": ["recipient@example.com"], "subject": "x" * 256},
                )


class ImapIdentityTests(unittest.TestCase):
    class FakeImap:
        def select(self, mailbox: str, readonly: bool = False):
            return "OK", [b"3"]

        def response(self, name: str):
            return "UIDVALIDITY", [b"42"]

    def test_uidvalidity_mismatch_stops_action(self) -> None:
        with self.assertRaises(StaleMessageError):
            select_folder(self.FakeImap(), "INBOX", readonly=True, expected_uidvalidity="41")

    def test_folder_control_characters_are_rejected_before_imap(self) -> None:
        with self.assertRaisesRegex(CoremailError, "control character"):
            select_folder(self.FakeImap(), "INBOX\r\nUID SEARCH ALL", readonly=True)


class LocalDiscoveryTests(unittest.TestCase):
    def test_deep_discovery_redacts_secrets_and_reads_sqlite_schema_only(self) -> None:
        with tempfile.TemporaryDirectory() as raw_directory:
            directory = Path(raw_directory)
            (directory / "account.json").write_text(
                json.dumps(
                    {
                        "username": "user@example.com",
                        "server_url": (
                            "https://user:url-secret@mail.example.com:8443/private/access-token"
                            "?token=top-secret"
                        ),
                        "password": "must-not-escape",
                        "cookie": "also-secret",
                    }
                ),
                encoding="utf-8",
            )
            (directory / "legacy.ini").write_text(
                "username=user@example.com\npassword=secret-password@example.net\n",
                encoding="utf-8",
            )
            database = directory / "mail.sqlite"
            connection = sqlite3.connect(database)
            connection.execute("CREATE TABLE messages (subject TEXT, sender TEXT, body TEXT)")
            connection.commit()
            connection.close()

            result = discover_local({"roots": [str(directory)], "deep": True, "max_files": 100})
            rendered = json.dumps(result, ensure_ascii=False)
            self.assertNotIn("must-not-escape", rendered)
            self.assertNotIn("also-secret", rendered)
            self.assertNotIn("top-secret", rendered)
            self.assertNotIn("url-secret", rendered)
            self.assertNotIn("access-token", rendered)
            self.assertNotIn("secret-password@example.net", rendered)
            self.assertIn("https://mail.example.com:8443", rendered)
            self.assertIn("<redacted>", rendered)
            self.assertIn("messages", rendered)
            self.assertFalse(result["secret_values_returned"])
            self.assertTrue(result["read_only"])


if __name__ == "__main__":
    unittest.main()
